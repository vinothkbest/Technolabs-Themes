 <?php 
//Menu Appearance
function esite_menus() {
  register_nav_menus(array('header' => 'Header',
  						   'footer' => 'Footer', 
  							'qlinks' => 'Quick Links'));

}

add_action('after_setup_theme', 'esite_menus');

//Post's Taxonomy & Featured Image


add_action('init', 'taxonomy_featuredimage');

function taxonomy_featuredimage() {
  add_theme_support('post-thumbnails');

}

//remove id & class in nav

function remove_nav_attributes($links){

	return $links = preg_replace('/id=\"(.*)\"/iU', '', $links);
}

add_filter('wp_nav_menu', 'remove_nav_attributes');

//Widgets Appearance
function esite_widgets(){
	register_sidebar(array( 'name' => __('Widgets', 'esite'),
							'id'   => 'side-1',
							'description'   => __('Widgets in this area will be shown on all posts and pages.', 'esite'),
							'before_widget' => '<li class="my_widget">',
							'after_widget' => '</li>',
							'before_title' => '<h2 class="my_widget_title">esite Header',
							'after_title' => '</h2>'	
					));
}

add_action('widgets_init', 'esite_widgets');

//Theme Styles & scripts

function esite_style_script(){
		   wp_enqueue_style('bootstrap.min', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css');
		   wp_enqueue_style('font-awesome.min', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css');
		   wp_enqueue_script('jquery.min', get_theme_file_uri().'/assets/js/lib/jquery.min.js');
		   wp_enqueue_script('bootstrap.min', get_theme_file_uri().'/assets/js/lib/bootstrap.min.js');
		   wp_enqueue_script('p5.min', get_theme_file_uri().'/assets/js/lib/p5.min.js');

		   wp_enqueue_style('header', get_theme_file_uri().'/assets/css/header.css');
		   wp_enqueue_style('footer', get_theme_file_uri().'/assets/css/footer.css');
		   wp_enqueue_style('index', get_theme_file_uri().'/assets/css/index.css');
		   wp_enqueue_script('index', get_theme_file_uri().'/assets/js/index.js');
		   wp_enqueue_script('header', get_theme_file_uri().'/assets/js/header.js');
		   wp_enqueue_script('footer', get_theme_file_uri().'/assets/js/footer.js');


}

add_action('wp_enqueue_scripts', 'esite_style_script');


?>