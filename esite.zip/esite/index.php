<?php get_header();

 		$scan = scandir('C:\XAMPP\htdocs\wordpress\wp-content\themes\esite\images\banner');
		$files = array_slice($scan, 2);

?>

<main>
 <!-- Banner -->
 <section class="banner">
       <div id="myCarousel" class="carousel slide" data-ride="carousel">
      <!-- Indicators -->
        <ol class="carousel-indicators">
          <?php foreach($files as $index => $image) : 
                if ($index === 0) :     ?>
                  <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
          <?php  else :  ?>
                  <li data-target="#myCarousel" data-slide-to="<?php $index; ?>"></li>
          <?php endif; endforeach;?>
                  <span id="toggleCarousel"><i class="fa fa-pause" style="font-size:18px"></i></span>
        </ol>

  <!-- Wrapper for slides -->
      <div class="carousel-inner">
        <?php  foreach($files as $index => $image) :
          if ($index === 0) :     ?>
              <div class="item active">
                <img src="<?php echo get_theme_file_uri().'/images/banner/'. $image ?>" alt="no slide" style="width:100%;;height:450px">
              </div>
        <?php  else :  ?>
               <div class="item">
                  <img src="<?php echo get_theme_file_uri().'/images/banner/'.$image ?>" alt="no slide" style="width:100%;height:450px">
                </div>             
        <?php endif; endforeach;?>
      </div>

      <!-- Left and right controls -->
      <span class="left carousel-control" href="#myCarousel" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left"></span>
      </span>
      <span class="right carousel-control" href="#myCarousel" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right"></span>
      </span>
    </div>
 </section> 

<!-- content -->
<section class="the-content">
  <div class="container">
    <div class="parent-pages">
      <?php 
          $parents = array('post_type' => 'page', 
                            'post_parent' => 0,
                            'post__not_in' => array(18, 108),
                            'orderby' => 'title',
                            'order' => 'asc');
          $parent_pages = new WP_Query($parents);

          if($parent_pages->have_posts()) :?>

            <?php while ($parent_pages->have_posts()) : $parent_pages->the_post();
              if (get_the_excerpt()) :?>

                <content>
                  <div id="parent-<?php the_id(); ?>" class="parent-page">                                
                    <img class="feature-image" src="<?php echo get_the_post_thumbnail_url() ?>" alt="<?php the_title()?>" height="50%" width="100%">
                    <div class="post-content">
                      <h3><?php the_title();?></h3>
                      <p style="text-align: justify;">
                        <?php
                                 // $content = explode(" ", get_the_excerpt());
                                 // $sliced = array_slice($content, 0, 25);
                                 // $excerpt = implode(" ", $sliced);
                                 // echo $excerpt . " ...";

                        $offset = strpos(get_the_content([], true), '.');
                        $about = substr(get_the_content([], true), 0, $offset);
                        echo $about . '.' ;
                        ?>
                      </p>
                      <p class="post-link"><a href="<?php the_permalink(); ?>" style="text-decoration: none; text-transform: uppercase;">Learn More</a></p>
                    </div>
                </div>
                <p class="strip" style='height:10px; background-color:#73b66f; width:50%; display:block'></p>
              </content>

        <?php  endif;
           endwhile;
          endif; ?>
    </div>
  </div>  
</section>
</main>

<?php get_footer();?>