<footer>
<div class="footer">
	<div class="container">
	<div class="footer-box">
		<div class="footer-icon">		
				<a href="http://localhost:8086/wordpress/"><img class="footer-logo" src="<?php echo get_site_icon_url(); ?>"></a>
		</div>
		<div class="footer-content">
			<div class="footer-menu">
				<nav class="nav-links">
						<p class="menu-title">Services & Training</p>
							<?php 
							       echo wp_nav_menu(array('theme_location'=>'footer',
						                            	  'container' =>'',
						                           		  'container_class' => ''));
						    ?>
			    </nav>
			    <nav class="quick-links">
						<p class="menu-title">Quick Links</p>
							<?php 
							       echo wp_nav_menu(array('theme_location'=>'qlinks',
						                            	  'container' =>'',
						                           		  'container_class' => ''));
						    ?>
			    </nav>
			</div>
		</div>	
    </div>
		<div class="social-links">	
			<a href=""><i class="fa fa-twitter social twitter"></i></a>
			<a href=""><i class="fa fa-linkedin social linkedin"></i></a>
			<a href=""><i class="fa fa-instagram social instagram"></i></a>
			<a href=""><i class="fa fa-pinterest social pinterest"></i></a>
			<a href=""><i class="fa fa-facebook social facebook"></i><a>
		</div>	
    </div>
    <p class="scroller" style="display:none;">
    	<i class="fa fa-angle-double-up" style="font-size: 40px; width: 40px; height:40px; border-radius: 50%;
  background: #014A87; color: white;"></i>
	</p>
</div>
</footer>
</body>
</html>