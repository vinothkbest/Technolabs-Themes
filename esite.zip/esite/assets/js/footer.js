$(document).ready(function(){       
    if ($(this).scrollTop() > 400) { 
        $('.scroller').fadeIn();
    } else { 
        $('.scroller').fadeOut(); 
    }  

    $('.scroller').on('click', function(){
		    $("html").animate({ scrollTop: "0px" }, 1000);
		    return false;
		});
    
});