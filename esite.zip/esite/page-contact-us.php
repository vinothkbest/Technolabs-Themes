<?php 
/*
Template Name: post
*/

get_header();?>


<main>
	<section class="poster">
		<div class="poster">
			<img src="<?php echo get_the_post_thumbnail_url() ?>" alt="<?php the_title()?>" height="450" width="100%">
		</div>
		<div class="container contact-content">
			<h3 style="font-weight:bolder;"><?php the_title()?></h3>
			<br/>
			    
			    <?php the_content();?>		    
		</div>
	</section>
</main>

<?php get_footer();?>